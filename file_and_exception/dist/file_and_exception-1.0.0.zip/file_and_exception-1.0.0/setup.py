from distutils.core import setup

setup(
    name = 'file_and_exception',
    version = '1.0.0',
    py_modules = ['file_and_exception'],
    author = 'Sun Jinbo',
    author_email = 'sunjinbo@outlook.com',
    url = 'www.python.org',
    description = 'file and exception module',
    )
