from distutils.core import setup

setup(
    name = 'persistent_storage',
    version = '1.0.0',
    py_modules = ['persistent_storage'],
    author = 'Sun Jinbo',
    author_email = 'sunjinbo@outlook.com',
    url = 'www.python.org',
    description = 'persistent storage module',
    )
